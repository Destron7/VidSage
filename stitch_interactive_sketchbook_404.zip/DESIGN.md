# Design System Strategy: The Tactile Manuscript

## 1. Overview & Creative North Star
The "Creative North Star" for this design system is **The Tactile Manuscript**. 

This is not a generic "doodle" theme. It is a high-end editorial experience that bridges the gap between the precision of digital interfaces and the soul of a physical sketchbook. We are moving away from the rigid, sterile grids of modern SaaS and toward a layout that feels curated, human-led, and intentionally asymmetrical. 

The aesthetic leverages "Organic Brutalism"—where the raw, unpolished nature of graphite and ink meets a sophisticated typographic hierarchy. We use overlapping elements, varying paper textures, and intentional "white space" (negative space) to create a sense of breathing room, ensuring the interface never feels cluttered despite its illustrative roots.

## 2. Colors & Surface Soul
Our palette mimics the physical tools of a creator: the cream of heavy-weight paper, the deep carbon of graphite, and the translucent pop of a highlighter.

### The "No-Line" Rule
Standard 1px solid borders are strictly prohibited for defining sections. In a sketchbook, sections are defined by the edge of the paper or the weight of the ink wash, not a mechanical stroke. Boundaries must be defined solely through background color shifts. Use `surface-container-low` (#f7f3ee) to define content areas against the main `background` (#fdf9f4).

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, physical sheets. 
- **Base Layer:** `surface` (#fdf9f4).
- **Secondary Content:** `surface-container` (#f1ede8) to create a subtle "recessed" feel.
- **Priority Elements:** Use `surface-container-highest` (#e6e2dd) for cards that need to feel like thick cardstock resting on top of the page.

### The "Glass & Gradient" Rule
To keep the system feeling premium rather than "flat," use Glassmorphism for floating overlays (e.g., Modals or Navigation Bars). Apply a `backdrop-blur` with a semi-transparent `surface` color. 
For main CTAs, do not use a flat fill. Instead, apply a subtle gradient from `primary` (#181818) to `primary-container` (#2c2c2c) at a 15-degree angle to mimic the sheen of fresh ink or a heavy graphite stroke.

## 3. Typography: The Editorial Contrast
We use a high-contrast pairing to balance personality with extreme legibility.

- **Display & Headlines (Epilogue):** These are our "inked" headers. Epilogue’s weight provides the structural authority of a printed journal. Use `display-lg` for hero moments to create an editorial, "title-page" feel.
- **Body & Labels (Plus Jakarta Sans):** Our "clean" UI voice. It provides the necessary clarity for functional tasks, ensuring that the "sketchbook" aesthetic never compromises usability.
- **The Handwritten Accent:** (To be used sparingly). Use a custom script font for decorative "annotations" or "doodle captions" to lean into the sketchbook vibe. These should never be used for critical UI path information.

## 4. Elevation & Depth
In this system, depth is a result of **Tonal Layering**, not structural shadows.

- **The Layering Principle:** Avoid the "shadow-on-white" look. Instead, place a `surface-container-lowest` (#ffffff) card on a `surface-container-low` (#f7f3ee) background. This creates a natural, soft lift that feels like a physical page-turn.
- **Ambient Shadows:** When an element must float (like a FAB), use a large, 24px-32px blur with the `on-surface` color (#1c1c19) at only **4% opacity**. The shadow should feel like a soft "glow" of darkness, rather than a hard drop shadow.
- **The "Ghost Border" Fallback:** If accessibility requires a border, use the `outline-variant` (#c4c7c7) at **15% opacity**. It should be felt, not seen—like a light pencil guideline.

## 5. Components

### Buttons
- **Primary:** Gradient fill (Primary to Primary-Container). Roundedness set to `md` (0.75rem) to avoid the "pill" cliche while remaining organic.
- **Secondary:** No fill. Use an organic, "hand-drawn" svg underline or a `surface-container-highest` background.
- **Tertiary/Highlighter:** Use `tertiary-fixed` (#dfec60) as a background for a "highlighted text" effect. Perfect for emphasizing a single keyword in a sentence.

### Input Fields
- **Styling:** No four-sided boxes. Use a bottom-only border (the "Graphite Line") using `outline`.
- **States:** On focus, the bottom border shifts to `primary` and a subtle `tertiary-container` (#2b2f00) "highlight" glow appears behind the text.

### Cards & Lists
- **The "No Divider" Rule:** Forbid 1px horizontal lines. Use vertical spacing (minimum 24px) or a alternating background shift between `surface-container-lowest` and `surface-container-low`.
- **Shape:** Use `xl` (1.5rem) roundedness or custom SVG "organic" clip-paths to make cards feel like hand-cut paper.

### Signature Component: The "Margin Note"
Use the `label-md` type in a `tertiary` (#171a00) color, placed asymmetrically in the margins of the layout. These act as tooltips or helpful hints, mimicking a student's notes in a textbook.

## 6. Do’s and Don’ts

### Do:
- **Embrace Asymmetry:** If a grid has three columns, let one be slightly wider or offset vertically by 16px.
- **Use "Ink Bleed" Textures:** Apply a very subtle grain texture (2-3% opacity) over the entire `background` to simulate paper tooth.
- **Interactive Doodles:** Use hand-drawn arrows (using `on-surface` color) to point toward primary CTAs.

### Don't:
- **Don’t use "Default" Icons:** Avoid generic Material or FontAwesome icons. Use custom, "rough-stroke" line icons that match the `primary` ink weight.
- **Don’t Over-Highlight:** The highlighter color (`tertiary-fixed`) is loud. Use it for no more than 5% of the screen real estate.
- **Don’t use Pure Black:** Never use #000000. Always use our "Graphite" `primary` (#181818) to maintain the analog feel.